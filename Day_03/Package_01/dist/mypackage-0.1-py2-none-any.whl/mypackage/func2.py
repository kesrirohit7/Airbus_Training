def funcC():
    print("This is func C")

def funcD():
    print("This is func D")
