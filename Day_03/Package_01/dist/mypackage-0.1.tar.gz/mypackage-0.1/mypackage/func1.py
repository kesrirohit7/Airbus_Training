def funcA():
    print("This is func A")

def funcB():
    print("This is func B")
