from setuptools import setup
setup(name = "mypackage",
version = "0.1",
description = "This is my package",
long_description = "This is long description",
author = "Rohit",
packages = ["mypackage"],
install_requires = []
)
