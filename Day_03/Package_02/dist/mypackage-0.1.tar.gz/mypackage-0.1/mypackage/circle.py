def area_circle(rad):
    return (22/7)*rad*rad
