from .square import area_square as sq_ar
from .circle import area_circle as cir_ar
from .sub_package import rec_ar

__all__ = ["sq_ar","cir_ar","rec_ar"]
