def area_square(l):
   return l*l
